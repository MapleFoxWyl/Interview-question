x = input().split()
print(' '.join(x[::-1]))
