x = input().split()

x = bin(int(x[0]))
print(x.count('1'))
