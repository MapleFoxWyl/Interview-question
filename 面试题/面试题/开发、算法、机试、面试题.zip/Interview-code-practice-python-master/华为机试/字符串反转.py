print(input()[::-1])
