while True:
    try:
        x = input()
        number = int(x)
        print(2.875 * number)
        print(0.03125 * number)
    except:
        break
