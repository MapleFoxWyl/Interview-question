import math
x = int(input())

n =( math.sqrt(1+4*x)-1)/2
print(int(n))