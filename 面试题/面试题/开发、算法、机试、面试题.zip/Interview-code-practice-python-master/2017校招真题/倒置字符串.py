x = input().split()
print(' '.join(list(map(str, x[::-1]))))
