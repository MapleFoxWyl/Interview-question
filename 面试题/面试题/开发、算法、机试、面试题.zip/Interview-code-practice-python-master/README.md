# Interview-code-practice-python

这是我为找工作准备的各类面试题，全部使用python实现

包括  剑指offer    csdn博客：http://blog.csdn.net/u012193416/article/details/79253398
